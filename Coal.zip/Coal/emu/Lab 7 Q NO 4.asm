.model small
.stack 100h
.data
    prompt db "Enter a single digit (0�9): $"
    newline db 0Ah, 0Dh, "$"
    Even db " is Even$"
    Odd db " is Odd$"
    input db ?

.code
main:
    mov ax, @data
    mov ds, ax

    mov ah, 09h
    lea dx, prompt
    int 21h

    mov ah, 01h
    int 21h
    mov input, al

    mov ah, 09h
    lea dx, newline
    int 21h

    mov dl, input
    mov ah, 02h
    int 21h

    mov ah, 09h
    lea dx, newline
    int 21h

    mov al, input
    sub al, '0'
    and al, 1
    mov ah, 09h
    lea dx, Odd
    test al, al
    jnz print
    lea dx, Even

print:
    mov ah, 09h
    int 21h

    mov ah, 4Ch
    int 21h
end main
