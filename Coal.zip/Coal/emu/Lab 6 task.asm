.model small
.stack 100
.data
   
   ;To take input for name
   
  promptname  db "Enter your name $"
  message db " Your name is :$" 
  newline db 0AH,0DH,"$" 
  
   ;Age hrdcore
age db "your age is :18$" 
     
   ;Take  semester
entersem  db "Enter your semester $"  
sem1 db " Your semester is :$" 
    
   
   enteruni  db "Enter the name of university $"  
   uni1 db " Your university is :$"
     
  inputBuffer db 20,0,20 DUP('$') 
  inputBuffer1 db 20,0,20 DUP('$')
  inputBuffer2 db 20,0,20 DUP('$')
.code  

   
mov ax,@data
mov ds,ax  
 ;for name

mov ah,09h 
lea dx,promptname
int 21h  
   
lea dx,inputBuffer  
mov ah,0Ah
int 21h
 
mov ah,09h 
lea dx,newline
int 21h   
  
mov ah,09h 
lea dx,message
int 21h   
    
lea dx,inputBuffer +2    
 mov ah,09h 
 int 21h  
 
;for age 
 
mov ah,09h 
lea dx,newline
int 21h   
 
 mov ah,09H
 lea dx,age
 int 21h    
 
mov ah,09h 
lea dx,newline
int 21h  
 

;for semster 
 
mov ah,09h 
lea dx,  entersem
int 21h  
   
lea dx,inputBuffer1  
mov ah,0Ah
int 21h
 
 mov ah,09h 
lea dx,newline
int 21h  
 
mov ah,09h 
lea dx,enteruni
int 21h  
   
lea dx,inputBuffer2  
mov ah,0Ah
int 21h  
  

 ;for university  
 
 
mov ah,09h 
lea dx,newline
int 21h   
  
mov ah,09h 
lea dx,uni1
int 21h   
    
lea dx,inputBuffer2 +2    
 mov ah,09h 
 int 21h 
 
  mov ah,09h 
lea dx,newline
int 21h  
 
 mov ah,09h 
lea dx,sem1
int 21h   
    
lea dx,inputBuffer1 +2    
 mov ah,09h 
 int 21h  
 
 
    
 
    
mov ah,4ch
int 21h
end
