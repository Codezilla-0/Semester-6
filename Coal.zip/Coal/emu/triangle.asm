.MODEL SMALL
.STACK 100H
.DATA        
.CODE
MAIN PROC      
              
        MOV CX, 5            ; Outer loop: 5 rows
    MOV SI, 1            ; Row counter starts at 1

OuterLoopP:
    MOV BX, SI           ; Copy current row number to BX (star count)
InnerLoopP:
    MOV DL, '*'          ; Character to print
    MOV AH, 2
    INT 21H

    DEC BX
    JNZ InnerLoopP        ; Print BX stars

    ; Print newline (carriage return + line feed)
    MOV DL, 13           ; Carriage return
    MOV AH, 2
    INT 21H
    MOV DL, 10           ; Line feed
    MOV AH, 2
    INT 21H

    INC SI               ; Move to next row (increase star count)
    LOOP OuterLoopP       ; Decrease CX and repeat if not 0

              

    MOV CX, 5            ; Outer loop: 5 rows
    MOV SI, 5            ; Row counter starts at 1

OuterLoop:
    MOV BX, SI           ; Copy current row number to BX (star count)
InnerLoop:
    MOV DL, '*'          ; Character to print
    MOV AH, 2
    INT 21H

    DEC BX
    JNZ InnerLoop        ; Print BX stars

    ; Print newline (carriage return + line feed)
    MOV DL, 13           ; Carriage return
    MOV AH, 2
    INT 21H
    MOV DL, 10           ; Line feed
    MOV AH, 2
    INT 21H

    DEC SI               ; Move to next row (increase star count)
    LOOP OuterLoop       ; Decrease CX and repeat if not 0

    ; Exit program
    MOV AH, 4CH
    INT 21H
MAIN ENDP
END MAIN