.model small
.stack 100
.data

  promptname  db "Enter your name $"
  message db " Your name is :$"  
  newline db 0AH,0DH,"$" 
  inputBuffer db 20,0,20 DUP('$')
.code  

   
mov ax,@data
mov ds,ax  


mov ah,09h 
lea dx,promptname
int 21h  
   
lea dx,inputBuffer  
mov ah,0Ah
int 21h
 
mov ah,09h 
lea dx,newline
int 21h   
  
mov ah,09h 
lea dx,message
int 21h   
    
lea dx,inputBuffer +2    
 mov ah,09h 
 int 21h  
 
    
mov ah,4ch
int 21h
end
