.model small
.stack 100
.data
    pName1    db "Enter the 1st number: $"
    pName2    db "Enter the 2nd number: $"
    newLine        db 0Ah, 0Dh, "$"  
    
    result      db "Quotient: $"    
    remainderr   db ", Remainder: $"

    digit1          db ?
    digit2          db ?
    quotient       db ?
    remainder      db ?  
    
      inputBuffer1    db 10,0,10 dup('$')
    inputBuffer2   db 10,0,10 dup('$')

.code
main:
    mov ax, @data
    mov ds, ax

    mov ah, 09h
    lea dx, pName1
    int 21h

    lea dx, inputBuffer1
    mov ah, 0Ah
    int 21h

    mov ah, 09h
    lea dx, newLine
    int 21h

    mov ah, 09h
    lea dx, pName2
    int 21h

    lea dx, inputBuffer2
    mov ah, 0Ah
    int 21h

    mov ah, 09h
    lea dx, newLine
    int 21h

    mov al, inputBuffer1 + 2
    sub al, '0'
    mov digit1, al

    mov al, inputBuffer2 + 2
    sub al, '0'
    mov digit2, al

    mov ax, 0       
    mov al, digit1   
    mov bl, digit2   
    xor ah, ah      
    div bl          

    mov quotient, al
    mov remainder, ah

    mov ah, 09h
    lea dx, result
    int 21h

    mov al, quotient
    add al, '0'
    mov dl, al
    mov ah, 02h
    int 21h

    mov ah, 09h
    lea dx, remainderr
    int 21h

    mov al, remainder
    add al, '0'
    mov dl, al
    mov ah, 02h
    int 21h

    
    mov ah, 4Ch
    int 21h

end main
