.model small
.stack 100h
.data
promptname db "Enter the two digit number : $"
newline    db 0Ah, 0Dh, "$"
resultmsg db "THE ANSWER IS : $"
inputBuffer db 20, 0, 20 dup('$')
RES db ?,'$'

.code
main:
mov ax, @data
mov ds, ax

mov ah, 09h
lea dx, promptname
int 21h

lea dx, inputBuffer
mov ah, 0Ah
int 21h

mov al, [inputBuffer + 2]
mov bl, al

mov al, [inputBuffer + 3]
mov bh, al

mov al, bl
sub al, bh
add al, '0'
mov RES, al

mov ah, 09h
lea dx, newline
int 21h

mov ah, 09h
lea dx, resultmsg
int 21h

mov dl, RES
mov ah, 02h
int 21h

mov ah, 4Ch
int 21h
end main
