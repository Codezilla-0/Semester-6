.model small
.stack 100
.data
    prompt db "Enter two >= to three digit(e.g: 342): $"
    newLine     db 0Ah, 0Dh, "$"
    d1 db 0Dh, 0Ah, "Digit 1 : $"
    d2 db 0Dh, 0Ah, "Digit 2 : $"
    d3 db 0Dh, 0Ah, "Digit 3 : $"
    inputBuffer db 20, 0, 20 dup('$')

    square1 db ?
    square2 db ?
    square3 db ? 
     V1   db ?
    V2   db ?
    V3   db ?

.code
main:
    mov ax, @data
    mov ds, ax            
    
    mov ah, 09h
    lea dx, prompt
    int 21h   
    
    lea dx, inputBuffer
    mov ah, 0Ah
    int 21h    
    
    mov ah, 09h
    lea dx, newline
    int 21h
            
    mov al, inputbuffer +2
    sub al, '0'
    mov V1, al
    
    mov al, inputbuffer +3
    sub al, '0'
    mov V2, al
    
    mov al, inputbuffer +4
    sub al, '0'
    mov V3, al    
    
    mov al, V1
    mul al
    mov square1, al
    
    mov al, V2
    mul al
    mov square2, al
    
    mov al, V3
    mul al
    mov square3, al 
    
    mov ah, 09h
    lea dx, d1
    int 21h     
    
    mov al, square1
    add al, '0'
    mov dl, al
    mov ah, 02h
    int 21h
    
    mov ah, 09h
    lea dx, d2
    int 21h
    
    mov al, square2
    add al, '0'
    mov dl, al
    mov ah, 02h
    int 21h
    
    mov ah, 09h
    lea dx, d3
    int 21h
    
    mov al, square3
    add al, '0'
    mov dl, al
    mov ah, 02h
    int 21h
    
    mov ah, 4Ch
    int 21h

end main

     