.model small
.stack 100
.data
 message db "Hello World$"
.code
mov ax,@data
mov ds,ax
lea dx,message

mov ah,09h
int 21h
mov ah,4ch
int 21h
end
