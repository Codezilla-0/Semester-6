.model small
.stack 100h

.data
menu db 13,10,'+-----------------------------+',13,10
     db '�      ASCII Calculator       �',13,10
     db '+-----------------------------�',13,10
     db '� 1. Addition                 �',13,10
     db '� 2. Subtraction              �',13,10
     db '� 3. Multiplication           �',13,10
     db '� 4. Division                 �',13,10
     db '� 5. Modulus                  �',13,10
     db '� 6. Square Root              �',13,10
     db '� 7. Power                    �',13,10
     db '� 8. Factorial                �',13,10
     db '� 9. Exit                     �',13,10
     db '+-----------------------------+',13,10
     db 'Select option (1-9): $'

prompt1 db 13,10,'Enter first number: $'
prompt2 db 13,10,'Enter second number: $'
result_msg db 13,10,'Result: $'
newline db 13,10,'$'
error_msg db 13,10,'Error: Invalid input!$'
num1 db 7 dup('$')
num2 db 7 dup('$')
buffer db 7 dup('$')

.code
main:
    mov ax, @data
    mov ds, ax

menu_loop:
    ; Show menu
    mov ah, 09h
    lea dx, menu
    int 21h

    ; Read choice
    mov ah, 01h
    int 21h
    cmp al, '1'
    jb invalid_input
    cmp al, '9'
    ja invalid_input

    sub al, '0'
    mov bl, al

    cmp bl, 1
    je do_add
    cmp bl, 2
    je do_sub
    cmp bl, 3
    je do_mul
    cmp bl, 4
    je do_div
    cmp bl, 5
    je do_mod
    cmp bl, 6
    je do_sqrt
    cmp bl, 7
    je do_power
    cmp bl, 8
    je do_fact
    cmp bl, 9
    je exit

invalid_input:
    mov ah, 09h
    lea dx, error_msg
    int 21h
    jmp menu_loop

;================ INPUT =================
get_number proc
    push si
    mov ah, 09h
    lea dx, prompt1
    int 21h
    lea si, num1
    call read_string
    call str2int
    pop si
    ret
get_number endp

get_two_numbers proc
    push si

    ; First number
    mov ah, 09h
    lea dx, prompt1
    int 21h
    lea si, num1
    call read_string
    call str2int
    mov cx, ax

    ; Second number
    mov ah, 09h
    lea dx, prompt2
    int 21h
    lea si, num2
    call read_string
    call str2int
    mov dx, ax

    pop si
    ret
get_two_numbers endp

read_string proc
    push ax
    push cx
    push si

    xor cx, cx
    mov ah, 01h
read_loop:
    int 21h
    cmp al, 13
    je done_read
    cmp al, '0'
    jb invalid_char
    cmp al, '9'
    ja invalid_char

    mov [si], al
    inc si
    inc cx
    cmp cx, 5
    jl read_loop

done_read:
    mov byte ptr [si], '$'
    jmp read_exit

invalid_char:
    mov ah, 09h
    lea dx, error_msg
    int 21h
    mov cx, 6
    lea di, num1
    mov al, '$'
    rep stosb

read_exit:
    pop si
    pop cx
    pop ax
    ret
read_string endp

;================ STR TO INT =================
str2int proc
    push bx
    push cx
    push dx
    push si

    xor ax, ax
    xor bx, bx
    mov cx, 10

next_digit:
    mov bl, [si]
    cmp bl, '$'
    je end_str2int
    sub bl, '0'
    mul cx
    add ax, bx
    inc si
    jmp next_digit

end_str2int:
    pop si
    pop dx
    pop cx
    pop bx
    ret
str2int endp

;================ INT TO STR =================
print_number proc
    push ax
    push bx
    push cx
    push dx
    push di

    test ax, ax
    jns positive
    push ax
    mov dl, '-'
    mov ah, 02h
    int 21h
    pop ax
    neg ax

positive:
    xor cx, cx
    lea di, buffer+6
    mov byte ptr [di], '$'

convert_loop:
    dec di
    xor dx, dx
    mov bx, 10
    div bx
    add dl, '0'
    mov [di], dl
    inc cx
    test ax, ax
    jnz convert_loop

    mov ah, 09h
    mov dx, di
    int 21h

    pop di
    pop dx
    pop cx
    pop bx
    pop ax
    ret
print_number endp

;================ OPERATIONS =================
do_add:
    call get_two_numbers
    mov ax, cx
    add ax, dx
    call display_result
    jmp menu_loop

do_sub:
    call get_two_numbers
    mov ax, cx
    sub ax, dx
    call display_result
    jmp menu_loop

do_mul:
    call get_two_numbers
    mov ax, cx
    imul dx
    call display_result
    jmp menu_loop

do_div:
    call get_two_numbers
    mov ax, cx
    mov bx, dx
    cmp bx, 0
    je division_error
    cwd
    idiv bx
    call display_result
    jmp menu_loop

division_error:
    mov ah, 09h
    lea dx, error_msg
    int 21h
    jmp menu_loop

do_mod:
    call get_two_numbers
    mov ax, cx
    mov bx, dx
    cmp bx, 0
    je modulus_error
    cwd
    idiv bx
    mov ax, dx
    call display_result
    jmp menu_loop

modulus_error:
    mov ah, 09h
    lea dx, error_msg
    int 21h
    jmp menu_loop

do_sqrt:
    call get_number
    call sqrt
    call display_result
    jmp menu_loop

do_power:
    call get_two_numbers
    mov ax, 1         ; result = 1
    mov bx, cx        ; base
    mov cx, dx        ; exponent

power_loop:
    cmp cx, 0
    je power_done
    mul bx            ; AX = AX * BX (unsigned multiplication)
    dec cx
    jmp power_loop

power_done:
    call display_result
    jmp menu_loop
do_fact:
    call get_number
    mov cx, ax        ; number in CX
    mov ax, 1         ; result = 1

fact_loop:
    cmp cx, 1
    jl factorial_done
    mul cx
    dec cx
    jmp fact_loop

factorial_done:
    call display_result
    jmp menu_loop

;================ SQRT =================
sqrt proc
    push bx
    push cx
    push dx

    mov bx, ax
    cmp ax, 0
    je sqrt_done

    mov ax, bx
    shr ax, 1
    inc ax
    mov cx, ax

sqrt_loop:
    mov ax, bx
    xor dx, dx
    div cx
    add ax, cx
    shr ax, 1
    cmp ax, cx
    jae sqrt_done
    mov cx, ax
    jmp sqrt_loop

sqrt_done:
    mov ax, cx

    pop dx
    pop cx
    pop bx
    ret
sqrt endp

display_result proc
    push ax
    push dx

    mov ah, 09h
    lea dx, result_msg
    int 21h

    pop dx
    pop ax
    call print_number

    mov ah, 09h
    lea dx, newline
    int 21h
    ret
display_result endp

exit:
    mov ah, 4Ch
    int 21h

end main