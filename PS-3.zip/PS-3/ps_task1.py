suspect_graph = {
    'S1': {'S2', 'S3', 'S4', 'S5'},
    'S2': {'S1', 'S3', 'S4', 'S5'},
    'S3': {'S1', 'S2', 'S4', 'S5'},
    'S4': {'S1', 'S2', 'S3', 'S5'},
    'S5': {'S1', 'S2', 'S3', 'S4'},
    'S6': {'S1'}
}

# Check for clique of size 5
find_clique_of_size(suspect_graph, 5)
# Output: Clique found: ('S1', 'S2', 'S3', 'S4', 'S5')

# Check for clique of size 6
find_clique_of_size(suspect_graph, 6)
# Output: No clique of size 6 found.